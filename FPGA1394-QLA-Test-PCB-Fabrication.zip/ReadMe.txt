These files contain the necessary information to manufacture
a printed circuit board.

Board Name: FPGA/QLA Test, Rev 1
Release Date: 12/10/2012

The files included are:
1-  ReadMe.txt                This file
2-  FPGA1394-QLA-Test.GTL     Top side routing layer
3-  FPGA1394-QLA-Test.GBL     Bottom side routing layer
4-  FPGA1394-QLA-Test.GTO     Top side silk screen mask
5-  FPGA1394-QLA-Test.GTS     Top side solder mask
6-  FPGA1394-QLA-Test.GBS     Bottom side solder mask
7-  FPGA1394-QLA-Test.DRL     Excellon drill file
8-  FPGA1394-QLA-Test.TXT     Text of drill file

NOTE:

1) The Gerber files include RS427X embedded apertures. No separate
   aperture file is provided.

FAB INSTRUCTIONS:
- Vendor and process shall be UL 94V-0 approved.
- Boards must be marked with vender identification and UL 94V-0
- Material: FR4
- Thickness 0.062"
- Vias: Top-Bottom only.
- Solder mask: LPI   Color: green
- Silkscreen on top side. Color: white
- Fab tolerance .XX = +/- .005
- Copper Weight:  1 Oz Copper on all layers
- Holes specified as larger than 0.021" diameter must remain open.
  Smaller diameter holes may be plugged or open.
